﻿using Microsoft.Xna.Framework;

namespace CGCCPlatformer.UI.Common.Bar
{
    public class DoubleEndedBar : FillableBar
    {
        public DoubleEndedBar(Rectangle bounds) : base(bounds)
        {
        }
    }
}
